/** Automatically generated file. DO NOT MODIFY */
package test.game.run;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}