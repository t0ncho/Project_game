//to stop the game -> call stopLoop()

//   important stuff

			var clearCanvasBtn = document.getElementById('clearCanvasBtn');        //make clear button
			clearCanvasBtn.addEventListener('click', clearCtxsBg,false);					//on click clear canvas
		    var canvasBg = document.getElementById('canvasBg');			//make background canvas
			var ctxBg = canvasBg.getContext('2d');
			var canvasJet = document.getElementById('canvasJet');				//make jet canvas
			var ctxJet = canvasJet.getContext('2d');
			var canvasEnemy = document.getElementById('canvasEnemy'); // make eneme
			var ctxEnemy = canvasEnemy.getContext('2d');
			var canvasHUD = document.getElementById('canvasHUD');		//canvas for hight score
			var ctxHUD = canvasHUD.getContext('2d');
			ctxHUD.fillStyle = "hsla(0, 0%, 0%, 0.5)"; 		//some color
			ctxHUD.font = "bold 20px Arial";  // font style
			
			
			jet1 = new Jet();		// create variable to object for jet
			var btnPlay = new Button(265, 535, 220, 335);			//button  that allow to click only the grew button
			var gameWidth = canvasBg.width;											//save the backgroun canvas windth into "gameWidth"
			var gameHeight = canvasBg.height;											//save the backgroun canvas height into "gameHeight"
			var mouseX = 0;
			var mouseY = 0;
			var isPlaying = false;						   							//boolean that chek if the game is playing
			var requestAnimFrame =  window.requestAnimationFrame ||    //chek the brouser
                        window.webkitRequestAnimationFrame ||
                        window.mozRequestAnimationFrame ||
                        window.msRequestAnimationFrame ||
                        window.oRequestAnimationFrame;
			
		
			
			var enemies = [];															//list of enemies		
			var imgSprite = new Image();										//make new img
			imgSprite.src = 'sprite.png';											// get the image from folder
			imgSprite.addEventListener('load',init,false);			//load the image
		
// end of important stuff

//BG
		var bgDrawX1 = 0;			//firt BG  and where it`s going to start
		var bgDrawX2 = 1600;		// secondBG  and it`s starting after the first0
		
		function moveBg(){
			bgDrawX1 -= 5;		// FisrtBG pic ...every move of screen it will also move 5px back 
			bgDrawX2 -=5;			//SecondBG ... it will also move 5 px back after the firt
				if(bgDrawX1 <= -1600){
					bgDrawX1 = 1600;
				}else if (bgDrawX2 <= -1600){
					bgDrawX2 = 1600;
				}
			drawBg();
		}
		
//BG		
		
		
//main functions
		
		function init(){
			drawBg();					//draw background
			spawnEnemy(5);		//make 5 enemy
			drawMenu();
			document.addEventListener('click',mouseClicked,false);
		}
		
		function playGame() {	
				startLoop();				//start loop
				updateHUD();			//update hightscore
				document.addEventListener('keydown',checkKeyDown,false);
				document.addEventListener('keyup',checkKeyUp,false);
		}
		
		function spawnEnemy(number){   // function gets "n" when we call it and type "spawnEnemy(5) " so "n" = 5
				for (var i = 0; i < number ; i++) { 			//cikal koito pravi novi enemy dokato ne stigne izbranoto cislo v sly4eq "5"
						enemies[enemies.length] = new Enemy();		//make new enemy in list  
						
				}
		}
		
		function drawAllEnemies(){
			clearCtxEnemy();	//tutorial 10  .. if we move enemy forward this will remove the shadow after every move ... clear the canvas before every function
			for (var i = 0; i < enemies.length; i++) {
					 enemies[i].draw();			
			}
		
		}
		
		
		function loop() {
			if (isPlaying) {			//chack if "isPlaying " is true
						moveBg();
						jet1.draw();				//draw jet
						drawAllEnemies();		//draw all enemies that are in "enemies" list
						requestAnimFrame(loop);		//call loop again
				}
		}
		
	
		function startLoop(){		
				isPlaying = true;			
				loop();					// call loop
		}

		function stopLoop(){	
				isPlaying = false ; 
		}
		
		function drawMenu() {
			var srcX = 0;						
			var srcY = 580;
			var drawX = 0 ;
			var drawY= 0 ;
			ctxBg.drawImage(imgSprite,srcX,srcY,gameWidth,gameHeight,drawX,drawY,gameWidth,gameHeight);			//draw the image
		}
		
		function drawBg(){			// draww background
			ctxBg.clearRect(0,0,gameWidth,gameHeight);
			//var srcX = 0;						
			//var srcY = 0;
			ctxBg.drawImage(imgSprite, 0, 0, 1600, gameHeight, bgDrawX1, 0, 1600, gameHeight);			//draw the image
			ctxBg.drawImage(imgSprite, 0, 0, 1600, gameHeight, bgDrawX2, 0, 1600, gameHeight);			//context.drawImage(img,sx,sy,swidth,sheight,x,y,width,height);
		}
		
		function updateHUD(){
			ctxHUD.clearRect(0,0,gameWidth,gameHeight);				//claer before write
			ctxHUD.fillText("Score: " + jet1.score,650,30);		// the actual text ...  actualText and  where to write it ("text", drawX , drawY)
		}
			
			function clearCtxsBg() {				//clear background canvas when the button is pressed
				ctxBg.clearRect(0,0,gameWidth,gameHeight);
			}
		
//end of main functions
		
//------------------------------------------------------------------------------------------------------------------		
//------------------------------------------------------------------------------------------------------------------
		
		
//Jet functions
		
		function Jet(){                				//object	for Jet
				this.srcX = 0;						// from where to start cuting in sprite a.k.a vertikal line
				this.srcY = 500; 					// from where to start cuting in sprite a.k.a horizontal line
				this.width = 100; 				//the width of the enemy pic a.k.a how long to  cut
				this.height = 40; 					//the height of the enemy pic a.k.a how hight to  cut
				this.speed = 2;					//2px every second or draw funct is call
				this.drawX = 200;				//where to draw it in the canvas 
				this.drawY  = 200;  				//where to draw it in the canvas
				this.noseX = this.drawX + 100;					// the front part of the plane "nose" 
				this.noseY= this.drawY + 30;					// the front  part of the plane "nose"
				this.leftX = this.drawX;
				this.rightX = this.drawX + this.width;
				this.topY = this.drawY;
				this.bottomY = this.drawY + this.height;
				this.isUpKey = false;
				this.isRightKey = false;
				this.isDownKey = false;
				this.isLeftKey = false;
				this.isSpacebar = false;
				this.isShooting = false;
				this.bullets = [];  					//define empty list for bullets
				this.currentBullet = 0; 		//counter for bullets
				for (var i = 0; i < 50 ; i++) { 				//when we make jet it make also 50 bullets , you have 50 bullets before the start to recucle .
						this.bullets[this.bullets.length] = new Bullet(this);			//make new bullet in lthe list , and also tell the bullet to wich jet his belong to 
				}
				this.score = 0;		//starting score
			}
		
		Jet.prototype.draw = function() {						//it`s normal function but shared betwen all jets
				clearCtxJet(); 												//tutorial 10  .. if we move jet forward this will remove the shadow after every move ... cleat the canvas before every function
				this.updateCoors();
				this.checkDirection();										//see which button is down before draw the jet
				this.checkShooting();
				this.drawAllBullets();
				ctxJet.drawImage(imgSprite,this.srcX,this.srcY,this.width,this.height,this.drawX,this.drawY,this.width,this.height);	 //from where to get the img , from where to where to cut , from where to where to paste and size
				};
				
		Jet.prototype.updateCoors = function(){
		
				this.noseX = this.drawX + 100;					
				this.noseY= this.drawY + 30;
				this.leftX = this.drawX;
				this.rightX = this.drawX + this.width;
				this.topY = this.drawY;
				this.bottomY = this.drawY + this.height;
				};
						
		Jet.prototype.checkDirection = function() {	
						if(this.isUpKey && this.topY > 0){
							this.drawY -= this.speed;
						}
						if(this.isRightKey && this.rightX < gameWidth){
							this.drawX += this.speed;
						}
						if(this.isDownKey && this.bottomY < gameHeight){
							this.drawY += this.speed;
						}
						if(this.isLeftKey && this.leftX > 0){
							this.drawX -= this.speed;
						}
				};
				
		Jet.prototype.drawAllBullets = function(){
			for (var i = 0; i < this.bullets.length; i++) {		
					if (this.bullets[i].drawX >= 0) {			//draw all bullets that have  "drawX" value over a "0"
							this.bullets[i].draw();
					}	
					if (this.bullets[i].explosion.hasHit) {
						this.bullets[i].explosion.draw();
					}
			}
		};
		
		Jet.prototype.checkShooting = function(){
				if(this.isSpacebar  && !this.isShooting) {							//check if spacebar is true and isShooting is false
						this.isShooting = true;
						this.bullets[this.currentBullet].fire(this.noseX, this.noseY)		//fire the curent bullet that is intthe list
						this.currentBullet++;						// raise the current bullet
						if (this.currentBullet >= this.bullets.length) {		//if current bullet is over the size of bullets packet it`s reloading
								this.currentBullet = 0;			//reload when the bullets go out of canvas
						}
					}else if (!this.isSpacebar) {  //if isShooting is false
								this.isShooting = false;
				}
		};
		
		
		Jet.prototype.updateScore = function(points){
				this.score += points;
				updateHUD();
		};
		
		
		function clearCtxJet() {				// clear Jet canvas
				ctxJet.clearRect(0,0,gameWidth,gameHeight);
			}
			
			
//end of Jet functions
			
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------	

//Bullet function

		function Bullet(j) {
				this.jet = j;		//tell the bullet to which jet his is belong to 
				this.srcX = 100;
				this.srcY = 500;
				this.drawX =  -20; 
				this.drawY = 0;
				this.width = 5;
				this.height = 5;
				this.explosion = new Explosion();
		}

		Bullet.prototype.draw = function() {						//it`s normal function but shared betwen all bullets
				this.drawX += 3;		//every time when the canvas is drawing the bullet i s mooving 3 'smth (pixels or ddz)' foward
				ctxJet.drawImage(imgSprite,this.srcX,this.srcY,this.width,this.height,this.drawX,this.drawY,this.width,this.height);	 //from where to get the img , from where to where to cut , from where to where to paste and size
				this.checkHitEnemy();
				if 	(this.drawX > gameWidth){			//check if the bullet go out of the canvas
						this.recycle();		//when the bullet go out of the canvas it reset from the begining
				}			
		};
	
		Bullet.prototype.fire = function(startX, startY) {	
				this.drawX = startX;		//start drawing from the nos� of the plane
				this.drawY =  startY;		//start drawing from the nos� of the plane 
		};

		Bullet.prototype.checkHitEnemy = function() {						//it`s normal function but shared betwen all bullets
			for (var i = 0; i < enemies.length; i++) {
					if(this.drawX >= enemies[i].drawX &&												//this hole "IF" check if the bullet is betwen front part , back part , top and button of the enemy ... 
						this.drawX <= enemies[i].drawX + enemies[i].width &&			//a.k.a. if the bullet is under the enemies
						this.drawY >= enemies[i].drawY &&
						this.drawY <=enemies[i].drawY + enemies[i].height) {
							this.explosion.drawX = enemies[i].drawX - (this.explosion.width / 2);			//BOOM
							this.explosion.drawY = enemies[i].drawY;															//BOOM
							this.explosion.hasHit = true;
							this.recycle();				//recucle the bullet (send it at the start, out of the canvas)
							enemies[i].recycleEnemy();			// recycle the  hit enemie (returned it out of the canvas )
							this.jet.updateScore(enemies[i].rewardPoints);			//pass the number of points you get for the hit to the score in jet1
					}		
			}
		};

		Bullet.prototype.recycle = function() {						//it`s normal function but shared betwen all bullets
					this.drawX = -20;				//get the bullet out of the screen canvas
		};

		
//end of Bullet function
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------

//Explosion function
	function Explosion() {
				this.srcX = 750;
				this.srcY = 500;
				this.drawX =  0; 
				this.drawY = 0;
				this.width = 50;
				this.height = 50;
				this.hasHit = false;   //it`s true when hit enemie
				this.currentFrame = 0;
				this.totalFrame = 100;		//how long the explosion will stay on screen
	}

	Explosion.prototype.draw = function() {
    if (this.currentFrame <= this.totalFrames) {
      //  ctxJet.drawImage(imgSprite, this.srcX, this.srcY, this.width, this.height, this.drawX, this.drawY, this.width, this.height);    //drawing the explosion pic
        this.currentFrame++;
    } else {
        this.hasHit = false;
        this.currentFrame = 0;
    }
};

// edn of Explosion function

//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------

// Enemy function			
		function Enemy(){                		//object	for Enemy
				this.srcX = 0;						// from where to start cuting in sprite a.k.a vertikal line
				this.srcY = 530; 					// from where to start cuting in sprite a.k.a horizontal line
				this.width = 100; 				//the width of the enemy pic a.k.a how long to  cut
				this.height = 40; 					//the height of the enemy pic a.k.a how hight to  cut
				this.speed = 2;					//2px every second or draw funct is call
				this.drawX = Math.floor(Math.random() * 1000) + gameWidth;						//where to draw it in the canvas , random start position *ranodom number betwen 0-1000 + game screen*
				this.drawY  = Math.floor(Math.random() * 350);									//where to draw it in the canvas,  random start position , with some limit where not to go 
				this.rewardPoints = 5;			//that`s how many points you get when you hit enemie
				
		}
					
		Enemy.prototype.draw = function() {						//it`s normal function but shared betwen all enemies
				
				this.drawX -=this.speed; 								// auto moving foward ... *if it`s += going back* *if it`s Y goinf up*
				ctxEnemy.drawImage(imgSprite,this.srcX,this.srcY,this.width,this.height,this.drawX,this.drawY,this.width,this.height);	 //from where to get the img , from where to where to cut , from where to where to paste and size
				this.checkEscaped();			//call '"checkEscaped"
		};
		
		Enemy.prototype.checkEscaped = function() {              
				if(this.drawX + this.width <= 0) {		//check if the enemy pass the end of the screen ... 
						this.recycleEnemy();					//call recycleEnemy
				}		
		};
		
		Enemy.prototype.recycleEnemy = function() {
					this.drawX = Math.floor(Math.random() * 1000) + gameWidth;						//redraw the enemy in the begining
				this.drawY  = Math.floor(Math.random() * 350);														//redraw the enemy in the begining
					
		};
		
		
		function clearCtxEnemy() {				// clear Enemy canvas
				ctxEnemy.clearRect(0,0,gameWidth,gameHeight);
			}
			
//end of Enemy function
	
//------------------------------------------------------------------------------------------------------------------	
//------------------------------------------------------------------------------------------------------------------	

// button object
		function Button(xL, xR, yT, yB) {
			this.xLeft = xL;				//coordinates of the botton
			this.xRight = xR;			//coordinates of the botton
			this.yTop = yT;				//coordinates of the botton
			this.yBottom = yB; 	//coordinates of the botton
		}
		Button.prototype.checkClicked = function() {
					if(this.xLeft <= mouseX && mouseX <= this.xRight && this.yTop <= mouseY && mouseY <= this.yBottom) {		 //check if the mouse is under the button
						return true; 
					}
					
		};
	
//end of button object
	
//------------------------------------------------------------------------------------------------------------------	
//------------------------------------------------------------------------------------------------------------------
			
//event functions
			
			function mouseClicked(e){
				  mouseX = e.pageX - canvasBg.offsetLeft;			//coordinate of the mouse
				  mouseY = e.pageY - canvasBg.offsetTop;			//coordinate of the mouse
				  if (isPlaying === false) {
							if (btnPlay.checkClicked()) {		// if everithing is ok (is pressed at the correct plase) start game
									playGame();
							}
				  }
			}
			
			function checkKeyDown(e){
					var keyID = e.keyCode || e.which;                   // if keyID can`t open e."keyCode" it will use "e.which"
					if (keyID === 38  || keyID === 87){					//check for up arrow and "W" key 
							jet1.isUpKey = true;
							e.preventDefault();
					}
					if (keyID === 39  || keyID === 68){					//check for right arrow and "D" key 
							jet1.isRightKey = true;
							e.preventDefault();
					}
					if (keyID === 40  || keyID === 83){					//check for down arrow and "S" key 
							jet1.isDownKey = true;
							e.preventDefault();
					}
					if (keyID === 37 || keyID === 65){					//check for left arrow and "A" key 
							jet1.isLeftKey  = true;
							e.preventDefault();
					}
					if (keyID === 32 ){											//check spacebar
							jet1.isSpacebar  = true;
							e.preventDefault();
					}
			}
			
			function checkKeyUp(e){
					var keyID = e.keyCode || e.which;
					if (keyID === 38  || keyID === 87){					//check for up arrow and "W" key 
							jet1.isUpKey = false;
							e.preventDefault();
					}
					if (keyID === 39  || keyID === 68){					//check for right arrow and "D" key 
							jet1.isRightKey = false;
							e.preventDefault();
					}
					if (keyID === 40  || keyID === 83){					//check for down arrow and "S" key 
							jet1.isDownKey = false;
							e.preventDefault();
					}
					if (keyID === 37 || keyID === 65){					//check for left arrow and "A" key 
						jet1.isLeftKey  = false;	
						e.preventDefault();
					}
					if (keyID === 32 ){											//check spacebar
							jet1.isSpacebar  = false;
							e.preventDefault();
					}
		}
			
//end of event functions
		